package project;

public class Validation {
    // Predefined validation numbers
    private static final int ADMIN_VALIDATION_NUMBER = 12345; // Change this to your secret number
    private static final int DOCTOR_VALIDATION_NUMBER = 67890; // Change this to your secret number
    
    public static boolean isValidAdmin(int inputNumber) {
        return inputNumber == ADMIN_VALIDATION_NUMBER;
    }
    
    public static boolean isValidDoctor(int inputNumber) {
        return inputNumber == DOCTOR_VALIDATION_NUMBER;
    }
}
